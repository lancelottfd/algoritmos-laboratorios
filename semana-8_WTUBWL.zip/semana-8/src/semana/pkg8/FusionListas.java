/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package semana.pkg8;

/**
 *
 * @author LAB-USR-AREQUIPA
 */

class Nodo {
    int valor;
    Nodo siguiente;

    Nodo(int valor) {
        this.valor = valor;
    }
}

public class FusionListas {

    static Nodo fusionar(Nodo a, Nodo b) {
        Nodo dummy = new Nodo(0);
        Nodo actual = dummy;

        while (a != null && b != null) {
            if (a.valor < b.valor) {
                actual.siguiente = a;
                a = a.siguiente;
            } else {
                actual.siguiente = b;
                b = b.siguiente;
            }
            actual = actual.siguiente;
        }

        actual.siguiente = (a != null) ? a : b;

        return dummy.siguiente;
    }

    static void imprimir(Nodo nodo) {
        while (nodo != null) {
            System.out.print(nodo.valor + " ");
            nodo = nodo.siguiente;
        }
    }

    public static void main(String[] args) {

        Nodo a = new Nodo(1);
        a.siguiente = new Nodo(3);
        a.siguiente.siguiente = new Nodo(5);

        Nodo b = new Nodo(2);
        b.siguiente = new Nodo(4);
        b.siguiente.siguiente = new Nodo(6);

        Nodo resultado = fusionar(a, b);

        imprimir(resultado);
    }
}