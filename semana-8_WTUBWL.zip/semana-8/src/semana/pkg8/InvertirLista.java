/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package semana.pkg8;

/**
 *
 * @author LAB-USR-AREQUIPA
 */
public class InvertirLista {

    public static void invertir(int[] lista) {
        int izquierda = 0;
        int derecha = lista.length - 1;

        while (izquierda < derecha) {
            int temp = lista[izquierda];
            lista[izquierda] = lista[derecha];
            lista[derecha] = temp;
            izquierda++;
            derecha--;
        }
    }
    public static void main(String[] args) {
        int[] numeros = {1, 2, 3, 4, 5};

        invertir(numeros);
        for (int num : numeros) {
            System.out.print(num + " ");
        }
    }
}
