/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package semana.pkg8;

/**
 *
 * @author LAB-USR-AREQUIPA
 */
public static void main(String[] args) {

    Nodo a1 = new Nodo(1);
    a1.siguiente = new Nodo(3);
    a1.siguiente.siguiente = new Nodo(5);

    Nodo b1 = new Nodo(2);
    b1.siguiente = new Nodo(4);
    b1.siguiente.siguiente = new Nodo(6);

    imprimir(fusionar(a1, b1));
    System.out.println();

    // Caso 2: una lista vacía
    Nodo a2 = null;

    Nodo b2 = new Nodo(1);
    b2.siguiente = new Nodo(2);

    imprimir(fusionar(a2, b2));
    System.out.println();

    // Caso 3: números repetidos
    Nodo a3 = new Nodo(1);
    a3.siguiente = new Nodo(3);
    a3.siguiente.siguiente = new Nodo(3);

    Nodo b3 = new Nodo(1);
    b3.siguiente = new Nodo(2);

    imprimir(fusionar(a3, b3));
}