/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package semana.pkg8;

/**
 *
 * @author LAB-USR-AREQUIPA
 */
class Nodo {
    int valor;
    Nodo siguiente;

    Nodo(int valor) {
        this.valor = valor;
        this.siguiente = null;
    }
}
public class DeteccionCiclosFloyd {
    public static boolean tieneCiclo(Nodo cabeza) {
        Nodo lento = cabeza;
        Nodo rapido = cabeza;

        while (rapido != null && rapido.siguiente != null) {
            lento = lento.siguiente;                 
            rapido = rapido.siguiente.siguiente;   

            // Si se encuentran, hay ciclo
            if (lento == rapido) {
                return true;
            }
        }
        return false;
    }
    public static void main(String[] args) {
        Nodo n1 = new Nodo(1);
        Nodo n2 = new Nodo(2);
        Nodo n3 = new Nodo(3);
        Nodo n4 = new Nodo(4);
        // Conectar nodos
        n1.siguiente = n2;
        n2.siguiente = n3;
        n3.siguiente = n4;
        // Crear ciclo:
        n4.siguiente = n2;

        boolean resultado = tieneCiclo(n1);
        System.out.println("¿Tiene ciclo?: " + resultado);
    }
}